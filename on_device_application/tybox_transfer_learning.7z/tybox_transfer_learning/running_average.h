class RunningAverage{
  int count;
  float value;
  public:
    RunningAverage(){
      count = 0;
      value = 0;
    }
    float push(float new_value){
      if(count == 1000){
        count = 0;
        value = 0;
      }
      value = (value * count + new_value) / (count + 1);
      count++;
      
      return value;
    }
    float get_value(){
      return value;
    }
    int get_count(){
      return count;  
    }
    void reset(){
      count = 0;
      value = 0;
    }
};